import 'package:flutter/material.dart';

class SelectLanguage extends StatefulWidget {
  const SelectLanguage({super.key});

  @override
  State<SelectLanguage> createState() => _SelectLanguageState();
}

class _SelectLanguageState extends State<SelectLanguage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        alignment: Alignment .center,
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/images/gallery.png',width: 100, height: 130,),
              Text('Please select your Language',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 24),),
              SizedBox(
                height: 10,
              ),
              Text('You can change the Language\nat anytime',
                style: TextStyle(
                    fontSize: 18),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 10,
              ),
              SizedBox(
                height: 60,
                width: 300,
                child: ElevatedButton(onPressed: () {
                  Navigator.pushNamed(context, 'mobile');
                }, child: Text("NEXT"), style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF2E3B62),
                    textStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),

              Image.asset('assets/images/vector.png')
            ],
          ),
        ),
      ),
    );
  }
}