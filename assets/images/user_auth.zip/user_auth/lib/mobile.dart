import 'package:flutter/material.dart';

class EnterMobile extends StatefulWidget {
  const EnterMobile({super.key});

  @override
  State<EnterMobile> createState() => _EnterMobileState();
}

class _EnterMobileState extends State<EnterMobile> {

  TextEditingController countrycode = TextEditingController();
  @override
  void initState() {
    super.initState();
    // TODO: implement initState
    countrycode.text = "+91";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          onPressed: () {
            Navigator.pushNamedAndRemoveUntil(
                context, 'language', (route) => false);
          },
          icon: Icon(Icons.arrow_back,
          color: Colors.black),
        ),
      ),
      body: Container(
        alignment: Alignment .center,
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Please enter your mobile number',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 24),),
              SizedBox(
                height: 5,
              ),
              Text('You’ll receive a 4 digit code\nto verify next.',
                style: TextStyle(
                    fontSize: 18),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 40,
              ),
              Container(
                margin: EdgeInsets.only(left: 20, right: 20),
                height: 55,
                decoration: BoxDecoration(
                  border: Border.all(width: 2, color: Colors.grey),
                  borderRadius: BorderRadius.circular(10)),
                child: Row(
                  children: [
                    SizedBox(width: 10),
                    SizedBox(
                      width: 40,
                      child: TextField(
                        controller: countrycode,
                        decoration: InputDecoration(
                          border: InputBorder.none
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text('-', style: TextStyle(fontSize: 45, fontWeight: FontWeight.w300, color: Colors.grey)),
                    SizedBox(width: 10),
                    Expanded(
                        child: TextField(
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            hintText: 'Mobile Number',
                            border: InputBorder.none
                          ),
                        )
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 20,
              ),
              SizedBox(
                height: 60,
                width: 375,
                child: ElevatedButton(onPressed: () {
                  Navigator.pushNamed(context, 'otp');
                  }, child: Text("CONTINUE"), style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF2E3B62),
                  textStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
