import 'package:flutter/material.dart';
import 'package:user_auth/mobile.dart';
import 'package:user_auth/otp.dart';

import 'language.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: 'language',
      routes: {
        'language' : (context) => SelectLanguage(),
        'mobile' : (context) => EnterMobile(),
        'otp' : (context) => EnterOtp()
      },
    ));
}
