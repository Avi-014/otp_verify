//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import smart_auth

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  SmartAuthPlugin.register(with: registry.registrar(forPlugin: "SmartAuthPlugin"))
}
